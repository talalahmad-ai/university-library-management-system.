ASSIGNMENT 1 — UNIVERSITY LIBRARY MANAGEMENT SYSTEM
Student: Talal Ahmad (@talalahmad-ai)

UPLOAD THIS FILE AS THE MAIN REPORT:
Assignment_1_Talal_Ahmad_Submission.pdf

If your portal accepts a ZIP or supporting files, upload this complete package as well.
Planning_Workbook.xlsx and Editable_Planning/ contain editable planning sources.
Planning_Charts/ contains the full-resolution WBS and Gantt exports.
GitHub_Evidence/ contains genuine screenshots, actual capture times and the verified commit/Issue records.

PASTE THIS REPOSITORY URL IN THE SUBMISSION BOX:
https://github.com/talalahmad-ai/university-library-management-system.

Keep the final period in the repository URL. All schedule dates are labelled proposed. Scope is Assignment 1 only.
