# Assignment 1 submission checklist

Student: Talal Ahmad (@talalahmad-ai). Scope: Assignment 1 only.

| Assignment requirement | Submitted evidence |
|---|---|
| GitHub account and existing project repository | Repository_URL.txt; report cover; Appendix A |
| Project scope, objectives, assumptions and constraints | Report Section 1; README_GitHub.md; editable charter |
| Dated activities, milestones and deadlines | Sections 4–5; proposed dates clearly labelled; Planning_Workbook.xlsx |
| Responsibilities and estimated effort per task | Section 6; workbook RACI/Effort/Capacity; editable CSVs |
| Risk likelihood, impact and mitigation | Section 7; 12-risk register and workbook Risks sheet |
| Four compulsory folders | Appendix A; actual repository root |
| Git availability and clone | Section 8; verified existing repository clone and original history |
| At least three meaningful commits | Appendix C; complete actual SHA list in GitHub_Evidence/verification.json |
| One assigned Issue per major task | Appendices D–F; 16 unique actual Issues assigned to talalahmad-ai |
| WBS | Sections 2–3; editable draw.io and CSV; vector PDF/PNG |

Schedule dates are proposed because official submission deadlines were not supplied. The existing repository name includes its final period. The report identifies the single confirmed student and preserves actual preparation authorship. No later assignment is presented as completed.
